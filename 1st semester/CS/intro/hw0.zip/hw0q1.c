#include <stdio.h>
int main( )
{
 for (int i = 3; i > 0; i--) {
 printf("%d\n",i);
 }
 printf("Are you ready to rumble? Ohh yeah!\n");
 /*
 Well,
 Are you ready?
 */
 return 0;
}
